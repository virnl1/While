codigo = input("Digite o código do cofre: ")

while codigo != "cofre2025":
    print("Código incorreto. Tente novamente.")
    codigo = input("Digite o código do cofre: ")

print("Cofre aberto com sucesso!")
