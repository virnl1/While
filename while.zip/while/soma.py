soma = 0
numero = int(input("Digite um número inteiro (-5 para parar): "))

while numero != -5:
    soma += numero
    numero = int(input("Digite um número inteiro (-5 para parar): "))

print("A soma dos números digitados é:", soma)
