import random

jogador_a = 0
jogador_b = 0

while jogador_a <= jogador_b:
    jogador_a = random.randint(1, 6)
    jogador_b = random.randint(1, 6)
    
    print(f"Jogador A tirou: {jogador_a}")
    print(f"Jogador B tirou: {jogador_b}")
    print("----")

print("Jogador A venceu!")