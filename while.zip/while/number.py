numero = 0

while numero <= 20:
    if numero % 2 == 0:
        print(numero)
    numero += 1